from django.apps import AppConfig


class DfGoodsConfig(AppConfig):
    name = 'df_goods'
    verbose_name = "商品"
