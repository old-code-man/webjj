from cx_Freeze import setup, Executable
import distutils
import opcode
import os
import shutil
# Dependencies are automatically detected, but it might need
# fine tuning.
# build_options = {'packages': ['setuptools','django','distutils'], 'excludes': []}
# def copy_distutils_to_build_dir(build_dir):
#     # the code below was obtained from the distutils.py file created by
#     # virtualenv
#     import opcode
#     dirname = os.path.dirname
#     distutils_path = os.path.join(os.path.dirname(opcode.__file__), 'distutils')
#     target_dir = os.path.join(build_dir, 'distutils')
#     if os.path.isdir(target_dir):
#         shutil.rmtree(target_dir)
#     shutil.copytree(distutils_path, target_dir)
# copy_distutils_to_build_dir(join('build', 'exe.win32-3.4'))

distutils_path = os.path.join(os.path.dirname(opcode.__file__), 'distutils')
build_options = {'include_files': [], "excludes": ["distutils"],'includes': ['tiaozao_shop']}

base = 'console'

executables = [
    Executable('C:\\Users\\ljjozo111\\Desktop\\Python_Django_sqlite_ershou-master\\ershou\\manage.py', base=base, target_name = 'manage.py')
]

setup(name='app',
      version = '1.0',
      description = '',
      options = {'build_exe': build_options},
      executables = executables)

# copy_distutils_to_build_dir(os.path.join('build', 'exe.win32-3.4'))

